# Full-Stack Conversational AI App

## How to Run

1. Make sure Docker is installed.
2. Run `docker-compose up --build`

The app will be available at http://localhost:5173